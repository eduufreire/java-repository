public interface Vendavel {

    Double getValorVenda();

}
